#include <stdio.h>
#include <math.h>
#include <time.h>
#include <omp.h> 

#ifdef MAXI
#define mm 15
#elif MEDIUM
#define mm 10
#elif MINI
#define mm 7
#else
#error ""
#error "####################################################"
#error "# NPART n est pas correctement definie.            #"
#error "# Pour compiler, make NPART=MINI , MEDIUM ou MAXI  #"
#error "####################################################"
#error ""
#endif

#define npart 4*mm*mm*mm
/*
 *  Function declarations
 */

  void
  dfill(int,double,double[],int);

  void
  domove(int,double[],double[],double[],double);

  void
  dscal(int,double,double[],int);

  void
  fcc(double[],int,int,double);

  void
  forces(int,double[],double[],double,double);

  double
  mkekin(int,double[],double[],double,double);

  void
  mxwell(double[],int,double,double);

  void
  prnout(int,double,double,double,double,double,double,int,double);

  double
  velavg(int,double[],double,double);

  double 
  secnds(void);

/*
 *  Variable declarations
 */

  double epot;
  double vir;
  double count;

/*
 *  Main program : Molecular Dynamics simulation.
 */
int main(){
    int move;
    double x[npart*3], vh[npart*3], f[npart*3];
    double ekin;
    double vel;
    double sc;
    double start, time;


  /*
   *  Parameter definitions
   */

    double den    = 0.83134;
    double side   = pow((double)npart/den,0.3333333);
    double tref   = 0.722;
    double rcoff  = (double)mm/4.0;
    double h      = 0.064;
    int    irep   = 10;
    int    istop  = 20;
    int    iprint = 5;
    int    movemx = 20;

    double a      = side/(double)mm;
    double hsq    = h*h;
    double hsq2   = hsq*0.5;
    double tscale = 16.0/((double)npart-1.0);
    double vaver  = 1.13*sqrt(tref/24.0);

  /*
   *  Initial output
   */

    printf(" Molecular Dynamics Simulation example program\n");
    printf(" ---------------------------------------------\n");
    printf(" number of particles is ............ %6d\n",npart);
    printf(" side length of the box is ......... %13.6f\n",side);
    printf(" cut off is ........................ %13.6f\n",rcoff);
    printf(" reduced temperature is ............ %13.6f\n",tref);
    printf(" basic timestep is ................. %13.6f\n",h);
    printf(" temperature scale interval ........ %6d\n",irep);
    printf(" stop scaling at move .............. %6d\n",istop);
    printf(" print interval .................... %6d\n",iprint);
    printf(" total no. of steps ................ %6d\n",movemx);

  /*
   *  Generate fcc lattice for atoms inside box
   */
    fcc(x, npart, mm, a);
  /*
   *  Initialise velocities and forces (which are zero in fcc positions)
   */
    mxwell(vh, 3*npart, h, tref);
    dfill(3*npart, 0.0, f, 1);
  /*
   *  Start of md
   */
    printf("\n    i       ke         pe            e         temp   "
           "   pres      vel      rp\n  -----  ----------  ----------"
           "  ----------  --------  --------  --------  ----\n");

     start = secnds(); 

  /*
   * =================================================================
   *  Q4 (Version 1) : Région parallèle ouverte UNE SEULE FOIS.
   *    - forces()  → parallèle (#pragma omp for interne)
   *    - domove, mkekin, velavg, dscal, prnout → #pragma omp single
   *    Avantage : évite de recréer les threads à chaque appel de forces.
   *
   *  Q5 (Version 2) : TOUTES les fonctions sont parallélisées.
   *    - domove, mkekin, velavg, dscal → #pragma omp for interne
   *    - forces  → #pragma omp for interne
   *    - prnout  → #pragma omp single (I/O non parallélisable)
   *    Avantage : on parallélise aussi les fonctions auxiliaires.
   *
   *  La version active ci-dessous implémente Q5 (Version 2).
   * =================================================================
   */

  /*
   * ===== VERSION 1 (Q4) — alternative à décommenter ===============
   *
   * #pragma omp parallel default(shared) private(move)
   * {
   *   for (move=1; move<=movemx; move++) {
   *
   *     #pragma omp single
   *     domove(3*npart, x, vh, f, side);
   *
   *     forces(npart, x, f, side, rcoff);
   *
   *     #pragma omp single
   *     {
   *       ekin=mkekin(npart, f, vh, hsq2, hsq);
   *       vel=velavg(npart, vh, vaver, h);
   *       if (move<istop && fmod(move, irep)==0) {
   *         sc=sqrt(tref/(tscale*ekin));
   *         dscal(3*npart, sc, vh, 1);
   *         ekin=tref/tscale;
   *       }
   *       if (fmod(move, iprint)==0)
   *         prnout(move, ekin, epot, tscale, vir, vel, count, npart, den);
   *     }
   *   }
   * }
   *
   * ===== FIN VERSION 1 (Q4) =======================================
   */

    /* ===== VERSION 2 (Q5) — active ================================ */
    #pragma omp parallel default(shared) private(move)
    {
      double my_ekin, my_vel;  /* privées à chaque thread */

      for (move=1; move<=movemx; move++) {

      /*
       *  Move the particles and partially update velocities
       *  Q5 : domove utilise #pragma omp for en interne
       */
        domove(3*npart, x, vh, f, side);

      /*
       *  Compute forces in the new positions and accumulate the virial
       *  and potential energy.
       *  Q6 : forces utilise un tableau indexé par thread (pas de critical)
       */
        forces(npart, x, f, side, rcoff);

      /*
       *  Scale forces, complete update of velocities and compute k.e.
       *  Q5 : mkekin utilise #pragma omp for reduction en interne
       *  Chaque thread obtient le même résultat via la réduction.
       */
        my_ekin=mkekin(npart, f, vh, hsq2, hsq);

      /*
       *  Average the velocity and temperature scale if desired
       *  Q5 : velavg utilise #pragma omp for reduction en interne
       */
        my_vel=velavg(npart, vh, vaver, h);

      /*
       *  Un seul thread met à jour les variables partagées
       *  (évite la data race de plusieurs threads écrivant dans ekin/vel)
       */
        #pragma omp single
        {
          ekin = my_ekin;
          vel  = my_vel;
        }
        /* Barrière implicite → tous les threads voient ekin et vel */

        if (move<istop && fmod(move, irep)==0) {
          #pragma omp single
          sc=sqrt(tref/(tscale*ekin));
          /* Barrière implicite → tous les threads voient sc */

          dscal(3*npart, sc, vh, 1);  /* Q5 : parallélisé */
          /* Barrière implicite après omp for dans dscal */

          #pragma omp single
          ekin=tref/tscale;
        }

      /*
       *  Sum to get full potential energy and virial
       *  prnout fait du I/O (printf) → un seul thread
       */
        #pragma omp single
        {
          if (fmod(move, iprint)==0)
            prnout(move, ekin, epot, tscale, vir, vel, count, npart, den);
        }

      }
    } /* fin de la région parallèle Q5 */
    /* ===== FIN VERSION 2 (Q5) ====================================== */

    time = secnds() - start;  

    printf("Time =  %f\n",(float) time);  

  }

time_t starttime = 0; 

double secnds()
{

  return omp_get_wtime(); 

}

